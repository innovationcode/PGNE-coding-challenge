# PG&E - MRAD Node.js Coding Challenge

## Task :-- You need to create an AWS lambda function to do the following:

1. Create a RESTful API which executes the following steps for every request

- Using `Serverless` framework here, which allows you to build Serverless applications.

  - Requirements :---

    - node v15.4.0

    - `npm install -g serverless` which helps you to create boilerplate for serverless applications.

    - `serverless.yml` - The entry point file. Without it, Serverless won't run. It has three sections - provider, functions, resources, plugins, etc. Used provider AWS as per specification

- a. Pull data from this url: https://gbfs.divvybikes.com/gbfs/en/station_information.json

- b. Make some changes to the output from the url above:

1. Remove rental_methods and rental_uris from the output.
2. Rename: external_id, station_id, and legacy_id into externalId, stationId, and
   legacyId.
3. Return the data when the capacity is less
   Pull data from this url: https://gbfs.divvybikes.com/gbfs/en/station_information.json
   b. Make some changes to the output from the url above:
4. Remove rental_methods and rental_uris from the output.
5. Rename: external_id, station_id, and legacy_id into externalId, stationId, and
   legacyId.
6. Return the data when the capacity is less than 12.
   c. Convert your JSON output into CSV.
   d. Write your output into a filesystem as a .csv file.
   e. Upload your file to S3. (overwrite or create a new file)

Requirements
• Use Hapi (node framework).
• Use async/await.
• Add a unit-test for the API call.
• Use whatever node packages you like but don’t install a 3rd party databases,
caching,
